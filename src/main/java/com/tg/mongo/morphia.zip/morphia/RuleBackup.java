package com.tg.mongo.morphia;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.*;

/**
 * Created by linzc on 2018/9/13.
 */
public class RuleBackup {


}
